Installation du projet
Après avoir telechargé le fichier, vous devez vous rendre dans
le dossier contenant le projet en ligne de commande et tapez la commande suivante:
php -S localhost:8000 -t public

puis lancer votre navigateur, aller à l'adresse suivante:
localhost:8000/
la page de connexion s'ouvrira. Vous devez vous connecter pour acceder à l'application.
Voici une liste de comptes que vous pouvez utiliser:
1- admin, password: 123456
2- root, password: 123456,
3- isha, password: 123456,

Le module Palmares n'est pas encore fonctionnel, ainsi que la possibilité de modification
de password, de photo...

dans le future, nous aurons la génération d'horaire de cours, de palmares, de modifications
de password et de photo, un système de messagerie, la possibilité d'importer des listes
en csv, text, etc... Un système de pagination avec JQuery Datable qui sera très simple pour
le filtrage des données

Ce projet est réalisé par FOCUSLAB. Ce dernier est composé de:
1- Claudin SAINTIL
2- Nakisha LOUIS
3- Wesly TOUSSAINT

Nous remercions le prof Josué pour avoir choisi ce projet et pour nous avoir guidé
dans l'apprentissage du language PHP.
